apt-get update -y
apt-get install python ffmpeg wget -y