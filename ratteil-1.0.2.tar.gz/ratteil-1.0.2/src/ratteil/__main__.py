from . import ratteil 

if __name__ == "__main__":
  ratteil()