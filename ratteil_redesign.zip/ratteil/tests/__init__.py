"""Tests for RatTeil application."""
